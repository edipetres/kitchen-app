export default {
  apiUrl: {
    prod: 'https://0z38v1dlk4.execute-api.eu-central-1.amazonaws.com/dev/',
    dev: 'http://localhost:3000'
  }
}